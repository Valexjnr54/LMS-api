<?php

use App\Http\Controllers\api\UsersController;
use App\Http\Controllers\api\CourseController;
use App\Http\Controllers\api\AdminAuthController;
use App\Http\Controllers\api\LecturerAuthController;
use App\Http\Controllers\api\StudentAuthController;
use App\Http\Controllers\api\CourseAssignController;
use App\Http\Controllers\api\UploadCourseContentController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::prefix('v1')->group(function () {
    //User Route Starts
    Route::prefix('users')->group(function(){
        Route::get('/all-users', [UsersController::class, 'viewUsers']);
        Route::get('/single-user/{id}', [UsersController::class, 'viewSingleUser']);
        Route::delete('/delete-user/{id}', [UsersController::class, 'deleteUser']);
        Route::match(['put', 'patch','post'], '/update-user/{id}', [UsersController::class, 'updateUser']);
        Route::post('/create-user', [UsersController::class, 'createUser']);
        Route::get('/all-lecturers', [UsersController::class, 'lecturer']);
    });
    //User Route Ends

    //Student Route Starts
    Route::prefix('students')->group(function(){
        Route::get('/all-students', [UsersController::class, 'viewStudents']);
        Route::get('/single-student/{id}', [UsersController::class, 'viewSingleStudent']);
        Route::delete('/delete-student/{id}', [UsersController::class, 'deleteStudent']);
        Route::match(['put', 'patch','post'], '/update-student/{id}', [UsersController::class, 'updateStudent']);
        Route::post('/create-student', [UsersController::class, 'createStudent']);
    });
    //Student Route Ends

    //Course Route Starts
    Route::prefix('courses')->group(function(){
        Route::get('/all-courses',[CourseController::class, 'viewCourses']);
        Route::get('/single-course/{id}',[CourseController::class, 'viewSingleCourse']);
        Route::delete('/delete-course/{id}',[CourseController::class, 'deleteCourse']);
        Route::match(['put','patch','post'], '/update-course/{id}', [CourseController::class, 'updateCourse']);
        Route::post('/create-course',[CourseController::class, 'createCourse']);
    });
    //Course Route Ends

    //Admin Authentication Route Starts
    Route::prefix('admin')->group(function()
    {
        Route::group(['middleware' => ['api']], function () {
            Route::post('/register', [AdminAuthController::class, 'register']);
            Route::post('/login', [AdminAuthController::class, 'login']);
            Route::get('/profile', [AdminAuthController::class, 'profile']);
            Route::post('/logout', [AdminAuthController::class, 'logout']);
        });
    });
    //Admin Authentication Route Ends

    //Lecturer Authentication Route Starts
    Route::prefix('lecturer')->group(function()
    {
        Route::group(['middleware' => ['api']], function () {
            Route::post('/login', [LecturerAuthController::class, 'login']);
            Route::get('/profile', [LecturerAuthController::class, 'profile']);
            Route::post('/logout', [LecturerAuthController::class, 'logout']);
        });
    });
    //Lecturer Authentication Route Ends

    //Student Authentication Route Starts
    Route::prefix('student')->group(function()
    {
        Route::group(['middleware' => ['api']], function () {
            Route::post('/register', [StudentAuthController::class, 'register']);
            Route::post('/login', [StudentAuthController::class, 'login']);
            Route::get('/profile', [StudentAuthController::class, 'profile']);
            Route::post('/logout', [StudentAuthController::class, 'logout']);
        });
    });
    //Student Authentication Route Ends

    //Assign & Unassign Courses Route Starts
    Route::prefix('assign-unassign')->group(function(){
        Route::group(['middleware' => ['api']],function()
        {
            Route::post('/assign-course', [CourseAssignController::class, 'assignCourses']);
            Route::post('/unassign-course', [CourseAssignController::class, 'unassignCourses']);
            Route::get('/assigned-course/{lecturer_id}', [CourseAssignController::class, 'assignedCourses']);
        });
    });
    //Assign & Unassign Courses Route Ends


    //Upload Course Route Starts
    Route::prefix('upload-course')->group(function(){
        Route::group(['middleware' => ['api']],function()
        {
            Route::get('/extract-content', [UploadCourseContentController::class, 'extractWebContent']);
            Route::post('/upload-content', [UploadCourseContentController::class, 'content']);
            Route::post('/upload-webcontent', [UploadCourseContentController::class, 'webContent']);
            Route::post('/upload-filecontent', [UploadCourseContentController::class, 'fileContent']);
            Route::post('/upload-videocontent', [UploadCourseContentController::class, 'videoContent']);
            Route::post('/upload-audiocontent', [UploadCourseContentController::class, 'audioContent']);
        });
    });
    //Upload Course Route Ends

    // Route::prefix('categories')->group(function(){
    //     Route::get('/all-categories', [CategoriesController::class, 'viewCategories']);
    //     Route::get('/single-category/{id}', [CategoriesController::class, 'viewSingleCategory']);
    //     Route::delete('/delete-category/{id}', [CategoriesController::class, 'deleteCategory']);
    //     Route::match(['put', 'patch'], '/update-category/{id}', [CategoriesController::class, 'updateCategory']);
    //     Route::post('/create-category', [CategoriesController::class, 'createCategory']);
    // });
});
